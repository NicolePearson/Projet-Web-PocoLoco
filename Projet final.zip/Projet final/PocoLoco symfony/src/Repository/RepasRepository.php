<?php

namespace App\Repository;

use App\Entity\Client;
use App\Entity\Commande;
use App\Entity\LigneCommande;
use App\Entity\Repas;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\Query\Expr\Join;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Repas|null find($id, $lockMode = null, $lockVersion = null)
 * @method Repas|null findOneBy(array $criteria, array $orderBy = null)
 * @method Repas[]    findAll()
 * @method Repas[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class RepasRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Repas::class);
    }

    /*Fonction permettant de récupérer 5 plats dans la table repas de la bdd*/
    public function find5Repas(){
        $qb = $this->createQueryBuilder('r')
            ->select('r')
            ->setMaxResults(5);
        return $qb->getQuery()->getResult();
    }

    /*Fonction permettant de récupérer les plats précédement acheter par un client*/
    public function findPrevious($idClient){
        $qb = $this->createQueryBuilder('r')
            ->select('r')
            ->innerJoin(LigneCommande::class, 'lgc', Join::WITH, "r.id = lgc.id_repas")
            ->innerJoin(Commande::class, 'cmd', Join::WITH, 'lgc.id_commande = cmd.id')
            ->innerJoin(Client::class, 'cl', Join::WITH, "cmd.id_client = cl.id")
            ->where('cl.id = :idClient')
            ->setParameter('idClient', $idClient);
        return $qb->getQuery()->getResult();
    }

    // /**
    //  * @return Repas[] Returns an array of Repas objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('r')
            ->andWhere('r.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('r.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Repas
    {
        return $this->createQueryBuilder('r')
            ->andWhere('r.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
