<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\CategorieRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=CategorieRepository::class)
 * @ApiResource()
 */
class Categorie
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({"read:collection"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=128)
     * @Groups({"read:collection"})
     */
    private $nom;

    /**
     * @ORM\OneToMany(targetEntity=Repas::class, mappedBy="id_cat")
     */
    private $id_repas;

    public function __construct()
    {
        $this->id_repas = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * @return Collection|Repas[]
     */
    public function getIdRepas(): Collection
    {
        return $this->id_repas;
    }

    public function addIdRepa(Repas $idRepa): self
    {
        if (!$this->id_repas->contains($idRepa)) {
            $this->id_repas[] = $idRepa;
            $idRepa->setIdCat($this);
        }

        return $this;
    }

    public function removeIdRepa(Repas $idRepa): self
    {
        if ($this->id_repas->removeElement($idRepa)) {
            // set the owning side to null (unless already changed)
            if ($idRepa->getIdCat() === $this) {
                $idRepa->setIdCat(null);
            }
        }

        return $this;
    }

    public function __toString()
    {

        return strval($this->getId());
        //return strval($this->getId())." ".$this->getNom();
    }


}
