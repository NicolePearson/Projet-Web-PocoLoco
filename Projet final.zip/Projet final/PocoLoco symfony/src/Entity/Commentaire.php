<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\CommentaireRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ApiResource(
 *     normalizationContext={"groups"={"repas:read"}},
 *     denormalizationContext={"groups"={"repas:write"}}
 * )
 * @ORM\Entity(repositoryClass=CommentaireRepository::class)
 */
class Commentaire
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({"repas:read", "repas:write"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups({"repas:read", "repas:write"})
     */
    private $auteur;

    /**
     * @ORM\Column(type="text")
     * @Groups({"repas:read", "repas:write"})
     */
    private $text;

    /**
     * @ORM\Column(type="datetime")
     * @Groups({"repas:read", "repas:write"})
     */
    private $date;

    /**
     * @ORM\ManyToOne(targetEntity=Repas::class, inversedBy="commentaires")
     * @ORM\JoinColumn(nullable=false)
     * @Groups({"repas:read", "repas:write"})
     */
    private $repas;

    /**
     * Commentaire constructor.
     * @param $date
     */
    public function __construct()
    {
        $this->date = new \DateTime( "now", new \DateTimeZone("Europe/Paris") );
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAuteur(): ?string
    {
        return $this->auteur;
    }

    public function setAuteur(string $auteur): self
    {
        $this->auteur = $auteur;

        return $this;
    }

    public function getText(): ?string
    {
        return $this->text;
    }

    public function setText(string $text): self
    {
        $this->text = $text;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getRepas(): ?Repas
    {
        return $this->repas;
    }

    public function setRepas(?Repas $repas): self
    {
        $this->repas = $repas;

        return $this;
    }
}
