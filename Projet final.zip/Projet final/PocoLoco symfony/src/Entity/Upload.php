<?php


namespace App\Entity;


use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class Upload
{
    /*Fonction pour l'upload d'une image*/
    public function uploadImg(UploadedFile $fichier){
        if($fichier){

            /*On récupère le nom original du fichier uploadé par le client*/
            $nomFichier = pathinfo($fichier->getClientOriginalName(), PATHINFO_FILENAME);
            /*On sécurise le nom du fichier*/
            $nomFichierSécurisé = transliterator_transliterate('Any-Latin; Latin-ASCII; [^A-Za-z0-9_] remove; Lower()', $nomFichier);
            /*On définit le nouveau nom du fichier avec un identifiant pour éviter que plusieurs fichiers aient le même nom*/
            $nouveauNomFichier = $nomFichierSécurisé.'-'.uniqid().'.'.$fichier->guessExtension();

            try{
                /*On bouge le fichier dans le répertoire souhaité*/
                $fichier->move('images/profile', $nouveauNomFichier);
            }catch (FileException $e){
                /*Cas d'erreur*/
                dd($e->getMessage());
            }
        }
        /*On retourne le nouveau nom du fichier*/
        return $nouveauNomFichier;
    }

}