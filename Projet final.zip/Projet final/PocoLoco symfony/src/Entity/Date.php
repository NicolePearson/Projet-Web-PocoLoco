<?php


namespace App\Entity;


class Date{
    /*Fonction qui récupère le jour en français*/
    public function getJour(){
        /*Tableau à clés => valeurs permettant de faire correspondre le numéro du jour au jour en français*/
        $jours = array(
            0=>'Dimanche',
            1=>'Lundi',
            2=>'Mardi',
            3=>'Mercredi',
            4=>'Jeudi',
            5=>'Vendredi',
            6=>'Samedi',
        );
        /*On récupère le numéro du jour actuel avec la fonction getdate() (0 correspond à dimanche et 6 à samedi) */
        $currentDay = getdate()['wday'];
        /*On parcourt le tableau avec les jours */
        foreach ($jours as $key=>$value){
            /*Si la clé du jour du tableau correspond au numéro récupéré par la fonction getdate()*/
            if($key == $currentDay){
                /*Alors on récupère la valeur de cette clé, soit le jour écrit en français*/
                $jourFR = $value;
            }
        }
        /*On retourne le jour en français*/
        return $jourFR;
    }

    /*Fonction qui récupère le mois en français*/
    public function getMois(){
        /*Tableau à clés => valeurs permettant de faire correspondre le numéro du mois au mois en français*/
        $mois = array(
            1=>'Janvier',
            2=>'Février',
            3=>'Mars',
            4=>'Avril',
            5=>'Mai',
            6=>'Juin',
            7=>'Juillet',
            8=>"Août",
            9=>'Septembre',
            10=>'Octobre',
            11=>'Novembre',
            12=>"Décembre",
        );
        /*On récupère le numéro du mois actuel avec la fonction getdate() */
        $currentMonth = getdate()['mon'];
        /*On parcourt le tableau avec les mois */
        foreach ($mois as $key=>$value){
            /*Si la clé du mois du tableau correspond au numéro récupéré par la fonction getdate()*/
            if($key == $currentMonth){
                /*Alors on récupère la valeur de cette clé, soit le mois écrit en français*/
                $moisFR = $value;
            }
        }
        /*On retourne le mois en français*/
        return $moisFR;
    }

    /* Méthode toString qui formatte l'affichage de la date en français */
    public function __toString()
    {
        return $this->getJour()." ".getdate()['mday']." ".$this->getMois()." ".getdate()['year'];
    }


}
?>