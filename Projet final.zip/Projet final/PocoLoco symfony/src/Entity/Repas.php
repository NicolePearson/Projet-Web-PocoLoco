<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\RepasRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass=RepasRepository::class)
 * @ApiResource(
 *     normalizationContext={
 *     "groups"={"read:collection"}
 *     },
 *     itemOperations={
       "get"= {
 *          "normalization_contexte" = {"groups" = {"read:collection", "read:item", "read:Repas"} }
 *     }
 *     }
 * )
 */
class Repas
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({"read:collection", "repas:read", "repas:write"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=128)
     * @Groups({"read:collection", "repas:read", "repas:write"})
     */
    private $designation;

    /**
     * @ORM\Column(type="decimal", precision=6, scale=2)
     */
    private $prix;

    /**
     * @ORM\Column(type="decimal", precision=5, scale=1)
     * @Groups({"read:collection", "repas:read", "repas:write"})
     */
    private $tva;

    /**
     * @ORM\Column(type="text")
     * @Groups({"read:collection", "repas:read", "repas:write"})
     */
    private $description;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups({"read:collection", "repas:read", "repas:write"})
     */
    private $img;

    /**
     * @ORM\Column(type="integer")
     * @Assert\Range(min=1, minMessage = "Please add a quantity above 0!")
     * @Groups({"read:item", "repas:read", "repas:write"})
     */
    private $quantite;

    /**
     * @ORM\ManyToOne(targetEntity=Categorie::class, inversedBy="id_repas",  cascade={"persist"})
     * @ORM\JoinColumn(nullable=false)
     * @Groups({"read:collection", "repas:read", "repas:write"})
     */
    private $id_cat;

    /**
     * @ORM\OneToMany(targetEntity=LigneCommande::class, mappedBy="id_repas",  cascade={"persist"})
     */
    private $ligneCommandes;

    /**
     * @ORM\OneToMany(targetEntity=Commentaire::class, mappedBy="repas")
     */
    private $commentaires;

    public function __construct()
    {
        $this->ligneCommandes = new ArrayCollection();
        return $this->id_cat;
        $this->commentaires = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDesignation(): ?string
    {
        return $this->designation;
    }

    public function setDesignation(string $designation): self
    {
        $this->designation = $designation;

        return $this;
    }

    public function getPrix(): ?string
    {
        return $this->prix;
    }

    public function setPrix(string $prix): self
    {
        $this->prix = $prix;

        return $this;
    }

    public function getTva(): ?string
    {
        return $this->tva;
    }

    public function setTva(string $tva): self
    {
        $this->tva = $tva;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getImg(): ?string
    {
        return $this->img;
    }

    public function setImg(string $img): self
    {
        $this->img = $img;

        return $this;
    }

    public function getQuantite(): ?int
    {
        return $this->quantite;
    }

    public function setQuantite(int $quantite): self
    {
        $this->quantite = $quantite;

        return $this;
    }

    public function getIdCat(): ?Categorie
    {
        return $this->id_cat;
    }

    public function setIdCat(?Categorie $id_cat): self
    {
        $this->id_cat = $id_cat;

        return $this;
    }

    public function __toString()
    {
        return $this->id_cat;
    }

    /**
     * @return Collection|LigneCommande[]
     */
    public function getLigneCommandes(): Collection
    {
        return $this->ligneCommandes;
    }

    public function addLigneCommande(LigneCommande $ligneCommande): self
    {
        if (!$this->ligneCommandes->contains($ligneCommande)) {
            $this->ligneCommandes[] = $ligneCommande;
            $ligneCommande->setIdRepas($this);
        }

        return $this;
    }

    public function removeLigneCommande(LigneCommande $ligneCommande): self
    {
        if ($this->ligneCommandes->removeElement($ligneCommande)) {
            // set the owning side to null (unless already changed)
            if ($ligneCommande->getIdRepas() === $this) {
                $ligneCommande->setIdRepas(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Commentaire[]
     */
    public function getCommentaires(): Collection
    {
        return $this->commentaires;
    }

    public function addCommentaire(Commentaire $commentaire): self
    {
        if (!$this->commentaires->contains($commentaire)) {
            $this->commentaires[] = $commentaire;
            $commentaire->setRepas($this);
        }

        return $this;
    }

    public function removeCommentaire(Commentaire $commentaire): self
    {
        if ($this->commentaires->removeElement($commentaire)) {
            // set the owning side to null (unless already changed)
            if ($commentaire->getRepas() === $this) {
                $commentaire->setRepas(null);
            }
        }

        return $this;
    }


}
