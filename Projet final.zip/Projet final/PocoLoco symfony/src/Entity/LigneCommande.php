<?php

namespace App\Entity;

use App\Repository\LigneCommandeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=LigneCommandeRepository::class)
 */
class LigneCommande
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $qte_repas;

    /**
     * @ORM\ManyToOne(targetEntity=Commande::class, inversedBy="ligneCommandes", cascade={"persist"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $id_commande;

    /**
     * @ORM\ManyToOne(targetEntity=Repas::class, inversedBy="ligneCommandes",  cascade={"persist"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $id_repas;


    public function __construct()
    {
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getQteRepas(): ?int
    {
        return $this->qte_repas;
    }

    public function setQteRepas(int $qte_repas): self
    {
        $this->qte_repas = $qte_repas;

        return $this;
    }


    public function getIdCommande(): ?Commande
    {
        return $this->id_commande;
    }

    public function setIdCommande(?Commande $id_commande): self
    {
        $this->id_commande = $id_commande;

        return $this;
    }

    public function getIdRepas(): ?Repas
    {
        return $this->id_repas;
    }

    public function setIdRepas(?Repas $id_repas): self
    {
        $this->id_repas = $id_repas;

        return $this;
    }

}
