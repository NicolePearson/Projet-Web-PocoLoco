<?php

namespace App\Form;

use App\Entity\Client;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CreateAccountType extends AbstractType
{
    /*Formulaire qui permet de créer un compte*/
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('email', EmailType::class, array('label'=>false))
            ->add('password', PasswordType::class, array('label'=>false))
            ->add('name', TextType::class, array('label'=>false))
            ->add('surname', TextType::class, array('label'=>false))
            ->add('address', TextType::class, array('label'=>false))
            ->add('postal_code', IntegerType::class, array('label'=>false))
            ->add('city', TextType::class, array('label'=>false))
            ->add('phone_number', IntegerType::class,array('label'=>false))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Client::class,
        ]);
    }
}
