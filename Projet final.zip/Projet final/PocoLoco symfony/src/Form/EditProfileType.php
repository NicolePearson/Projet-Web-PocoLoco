<?php

namespace App\Form;

use App\Entity\Client;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EditProfileType extends AbstractType
{
    /*Formulaire qui permet de modifier les données de son compte*/
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('fichier', FileType::class, ['required'=>false])
            ->add('name', TextType::class, ['required'=>false])
            ->add('surname', TextType::class, ['required'=>false])
            ->add('address', TextType::class, ['required'=>false])
            ->add('postal_code', IntegerType::class, ['required'=>false])
            ->add('city', TextType::class, ['required'=>false])
            ->add('phone_number',IntegerType::class, ['required'=>false])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            //'data_class' => Client::class,
        ]);
    }
}
