<?php

namespace App\Controller;

use App\Entity\Categorie;
use App\Entity\Client;
use App\Entity\Commande;
use App\Entity\Date;
use App\Entity\LigneCommande;
use App\Entity\Repas;
use App\Entity\Upload;
use App\Form\CreateAccountType;
use App\Form\EditProfileType;
use App\Form\QuantityType;
use DateTimeZone;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class DefaultController extends AbstractController
{

/*------------------------------
        PAGE D'ACCUEIL
-------------------------------*/

    /**
     * @Route("/", name="homepage")
     */
    public function index(): Response
    {
        /* Récupère toutes les catégories dans la BDD avec la fonction findAll du Repository de l'entité Catégorie */
        $categories = $this->getDoctrine()->getRepository(Categorie::class)->findAll();
        /* Récupère tous les plats dans la BDD avec la fonction findAll du Repository de l'entité Repas */
        $repas = $this->getDoctrine()->getRepository(Repas::class)->findAll();
        /* Requête personnalisée pour récupérer les cinq premiers plats dans la table repas, cette fonction se trouve
        dans le Repository de l'entité repas*/
        $cinqRepas = $this->getDoctrine()->getRepository(Repas::class)->find5Repas();

        return $this->render('default/index.html.twig', ['categories'=>$categories, 'repas'=>$repas, 'cinqRepas'=>$cinqRepas]);
    }

/*------------------------------------------------
        PAGE QUI PERMET DE VISUALISER UN PLAT
--------------------------------------------------*/

    /**
     * @Route("/vue-produit/{id}", name="vueProduit", requirements={"id"="\d+"})
     */
    public function vueProduit($id, Request $request): Response{

        /* Récupère un plat grâce à son id dans la BDD avec la fonction find du Repository de l'entité Repas */
        $produit = $this->getDoctrine()->getRepository(Repas::class)->find($id);
        /* Instanciation d'un nouveau repas qui sera celui du client*/
        $data = new Repas();
        /* Création du formulaire qui est définit dans la classe QuantityType, permet de choisir la quantité d'un plat */
        $form = $this->createForm(QuantityType::class, $data);
        /* Gère la soumission du formulaire */
        $form->handleRequest($request);

        /*Condition: Si le formulaire est soumis et est valide: */
        if ($form->isSubmitted() && $form->isValid() ) {
            /* On décrémente la quantité du plat par rapport à la quantité du plat ajouté au panier par le client */
            $quantite =  $produit->getQuantite() - $data->getQuantite();
            /*On redéfinit la quantité restante de ce plat*/
            $produit->setQuantite( $quantite );
            /* On met à jour la table repas dans la BDD de la quantité restante de ce plat*/
            $this->getDoctrine()->getManager()->flush();
            /* On récupère la session */
            $session = $request->getSession();
            /* On récupère une session nommée 'order' qui contient le contenu du panier du client*/
            $order = $session->get('order', []);
            /* On récupère le plat concerné dans la session 'order', par son id, puis on récupère la quantité du plat
            ajouté par le client */
            $order[$id] = $data->getQuantite();
            /* On redéfinit la session 'order'*/
            $session->set('order', $order);
            /* Message avertissant le client que le plat a bien été ajouté au panier*/
            $this->addFlash('success', 'Successfully added to your order!');

            return $this->redirectToRoute('vueProduit', ["id" => $id]);
        }
        /*Si le produit n'existe pas le client sera redirigé vers la page affichant tout les plats*/
        if($produit == null){
            return $this->redirectToRoute('allCategories');
        }

        return $this->render('default/vue-produit.html.twig', ['produit'=>$produit,
            'form' => $form->createView()]);
    }

/*------------------------------------------------
        PAGE QUI AFFICHE TOUT LES PLATS
--------------------------------------------------*/

    /**
     * @Route("/categorie/all", name="allCategories")
     */
    public function allCategories(Request $request): Response {
        /* Récupère tous les plats dans la BDD avec la fonction findAll du Repository de l'entité Repas */
        $cat = $this->getDoctrine()->getRepository(Repas::class)->findAll();
        /* Récupère toutes les catégories dans la BDD avec la fonction findAll du Repository de l'entité Catégorie */
        $lesCategories = $this->getDoctrine()->getRepository(Categorie::class)->findAll();
        /*Permet de récupérer le nom de la route actuelle*/
        $nomRoute = $request->attributes->get('_route');

        return $this->render('default/categorie.html.twig', ['categorie'=>$cat, 'lesCategories'=>$lesCategories, 'route'=>$nomRoute]);
    }

/*----------------------------------------------------
        PAGE QUI AFFICHE LES PLATS PAR CATEGORIE
------------------------------------------------------*/

    /**
     * @Route("/categorie/{id}", name="categorie", requirements={"id"="[1-4]"})
     */
    public function categorie($id, Request $request): Response{
        /* Récupère un plat par un critère, ici l'id de sa catégorie, dans la BDD avec la fonction findBy du Repository
        de l'entité Repas */
        $cat = $this->getDoctrine()->getRepository(Repas::class)->findBy(["id_cat"=>$id]);
        /* Récupère une catégorie par un critère, ici l'id, dans la BDD avec la fonction findBy du Repository
        de l'entité Categorie */
        $lesCategories = $this->getDoctrine()->getRepository(Categorie::class)->findBy(["id"=>$id]);
        /*Récupère le nom de la route actuelle*/
        $nomRoute = $request->attributes->get('_route');

        return $this->render('default/categorie.html.twig', ['categorie'=>$cat, 'lesCategories'=>$lesCategories, 'route'=>$nomRoute]);
    }

/*--------------------------
        PAGE PANIER
----------------------------*/

    /**
     * @Route("/order", name="order")
     */
    public function viewCart(Request $request) : Response{
        /* Instanciation d'une nouvelle date */
        $date = new Date();
        /*Je récupère la date écrit en français grâce à ma fonction dans la classe Date*/
        $date->getJour();
        /*On récupère la session 'order' du client*/
        $order = $request->getSession()->get('order', []);
        /*Nouveau tableau qui va stocker tout les éléments de la commande du client*/
        $orderData = [];
        /*On parcourt la session 'order'*/
        foreach($order as $id=>$quantite){
            /*On remplie le tableau avec le plat et sa quantité*/
            $orderData[] = [
                'repas' => $produit = $this->getDoctrine()->getRepository(Repas::class)->find($id),
                'quantite' => $quantite
            ];
        }
        /*Variable qui va stocker le prix total de la commande*/
        $prixTotal = 0;
        /*On calcul le prix total de tout le panier en parcourant le tableau*/
        foreach ($orderData as $order){
            /* On multiplie la quantité par le prix du plat*/
            $total = $order['repas']->getTva() * $order['quantite'];
            /*On additionne au prix final*/
            $prixTotal = $prixTotal + $total;
        }

        return $this->render('default/panier.html.twig', ["order"=>$orderData, "total"=>$prixTotal, "date"=>$date]);
    }

    /**
     * @Route("/order/remove/{id}", name="remove")
     */
    public function removeFromCart($id, Request $request){
        /*On récupère la session 'order' du client*/
        $order = $request->getSession()->get('order', []);
        /*Si la session 'order' n'est pas vide*/
        if(!empty($order[$id])) {
            /*On récupère la quantité du plat qui a été ajouté au panier*/
            $quantite = $order[$id];
            /* Récupère un plat grâce à son id dans la BDD avec la fonction find du Repository de l'entité Repas */
            $produit = $this->getDoctrine()->getRepository(Repas::class)->find($id);
            /*On incrémente dans la table repas la quantité du plat qui va être supprimer du panier*/
            $produit->setQuantite($quantite + $produit->getQuantite());
            /*Mise à jour de la BDD*/
            $this->getDoctrine()->getManager()->flush();
            /*On retire ce plat de la session également*/
            unset($order[$id]);
        }
        $request->getSession()->set('order',$order);
        return $this->redirectToRoute("order");
    }

/*--------------------------
        PAGE PAIEMENT
----------------------------*/

    /**
     * @Route("/order/payment", name="pay")
     */
    public function payer(Request $request){
        /*Impossible d'accéder à cette page si l'on est pas connecté*/
        $this->denyAccessUnlessGranted('IS_AUTHENTICATED_FULLY');
        /*Je récupère les données du client connecté*/
        $user = $this->getUser();
        /*On créé une nouvelle commande qui va stocker des données dans la table commande*/
        $commande = new Commande();
        /*On récupère la session 'order' du client*/
        $session = $request->getSession()->get('order', []);
        /*On définit l'id du client dans la commande*/
        $commande->setIdClient($user);
        /*On récupère la date et l'heure au moment du paiement de la commande */
        $zone = new DateTimeZone("Europe/Paris");
        $commande->setDate(new \DateTime("NOW", $zone));
        /*Variable qui va stocker le prix total de la commande*/
        $prixTotal = 0;
        /*Impossible d'accéder à cette page si la session 'order' est vide, le client n'a rien dans son panier*/
        if(empty($session)){
            /*Redirection vers la page du panier lui indiquant que son panier est vide*/
            return $this->redirectToRoute("order");
        }
        /*On parcourt la session 'order'*/
        foreach( $session as $id => $quantite){
            /* Récupère un plat grâce à son id dans la BDD avec la fonction find du Repository de l'entité Repas */
            $produit = $this->getDoctrine()->getRepository(Repas::class)->find($id);
            /*Nouvelle ligne de commande qui va contenir des données sur la commande*/
            $ligneCommande = new LigneCommande();
            /*On définit l'id du repas */
            $ligneCommande->setIdRepas($produit);
            /*On définit la quantité de ce repas*/
            $ligneCommande->setQteRepas($quantite);
            /*On ajoute les lignes commandes à la commande*/
            $commande->addLigneCommande($ligneCommande);
            /*On calcul le prix total du panier*/
            $prixTotal += $produit->getTva() * $quantite;
        }
        /*On définit le prix total du panier à la commande*/
        $commande->setPrixTotal($prixTotal);
        /*Après le paiement de la commande on vide la session 'order' du client, pour que son panier soit de nouveau vide*/
        $request->getSession()->remove("order");
        /*On insert dans la table commande les données de la commande effectué par le client*/
        $this->getDoctrine()->getManager()->persist($commande);
        /*Mise à jour de la BDD*/
        $this->getDoctrine()->getManager()->flush();

        return $this->render('default/payer.html.twig', []);
    }

/*------------------------------
        PAGE CREER COMPTE
-------------------------------*/

    /**
     * @Route("/registration", name="registration")
     */
    public function creerCompte(Request $request, UserPasswordEncoderInterface $encode){
        /*Instanciation d'un nouveau client*/
        $client = new Client();
        /* Création du formulaire qui est définit dans la classe CreateAccountType, permet de créer un compte */
        $form = $this->createForm(CreateAccountType::class, $client);
        /*Gère le submit du formulaire*/
        $form->handleRequest($request);
        /*Condition: Si le formulaire est soumis et est valide: */
        if($form->isSubmitted() && $form->isValid()){
            /*On encode le mot de passe*/
            $password = $encode->encodePassword($client, $client->getPassword());
            /*On définit le mot de passe encodé */
            $client->setPassword($password);
            $em = $this->getDoctrine()->getManager();
            /*Insertion dans la table CLient du nouveau client*/
            $em->persist($client);
            /*Mise à jour de la BDD*/
            $em->flush();
            /* Message avertissant le client que son compte a bien été créé*/
            $this->addFlash('success', 'Account successfully created!');
            /*Redirection vers la page login pour que le nouveau client puisse se connecter à son compte*/
            return $this->redirectToRoute('app_login');
        }

        return $this->render('security/signin.html.twig', ['form'=>$form->createView()]);
    }

/*------------------------------
        PAGE COMPTE
-------------------------------*/

    /**
     * @Route("/account", name="account")
     */
    public function compte(Request $request){
        /* Instanciation d'une nouvelle date */
        $date = new Date();
        /*Je récupère la date écrit en français grâce à ma fonction dans la classe Date*/
        $date->getJour();
        /* Instanciation d'un nouveau fichier (type image de profil) */
        $uploader = new Upload();
        /*Je récupère les données du client connecté*/
        $client = $this->getUser();
        /* Récupère un plat grâce à son id dans la BDD avec la fonction find du Repository de l'entité Repas */
        $ancienneCommandes = $this->getDoctrine()->getManager()->getRepository(Repas::class)->findPrevious($client->getId());
        /* Création du formulaire qui est définit dans la classe EditProfileType, permet de modifier ses données comme
        son adresse par exemple */
        $form = $this->createForm(EditProfileType::class);

        $form->get("name")->setData($client->getName());
        $form->get("surname")->setData($client->getSurname());
        $form->get("address")->setData($client->getAddress());
        $form->get("phone_number")->setData($client->getPhoneNumber());
        $form->get("postal_code")->setData($client->getPostalCode());
        $form->get("city")->setData($client->getCity());
        /* Gère la soumission du formulaire */
        $form->handleRequest($request);
        /*Condition: Si le formulaire est soumis et est valide: */
        if ($form->isSubmitted() && $form->isValid()) {
            /*On récupère le contenu du formulaire pour l'upload de l'image*/
            $fichier = $form->get("fichier")->getData();
            /*On upload l'image du client grâce à la fonction uploadImg dans l'entité Upload*/
            $img = $uploader->uploadImg($fichier);
            /*On redéfinit les données du client pour les éventuels changements*/
            $client->setName($form->get("name")->getData());
            $client->setSurname($form->get("surname")->getData());
            $client->setPhoneNumber($form->get("phone_number")->getData());
            $client->setAddress($form->get("address")->getData());
            $client->setPostalCode($form->get("postal_code")->getData());
            $client->setCity($form->get("city")->getData());
            /*On défint le chemin de l'image de profil*/
            $client->setProfileImg("images/profile/" . $img);
            /*Mise à jour de la BDD*/
            $this->getDoctrine()->getManager()->flush();
            /* Message avertissant le client que les données du compte ont bien été mis à jour*/
            $this->addFlash('success', 'Account successfully updated!');
            /*Redirection vers la page du compte*/
            return $this->redirectToRoute('account');
        }

        return $this->render('default/compte.html.twig', ['date'=>$date, 'client'=>$client, 'ancienne'=>$ancienneCommandes ,'form'=>$form->createView()]);
    }
}
