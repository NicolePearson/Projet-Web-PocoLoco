<?php

namespace App\Controller\Admin;

use App\Entity\Repas;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractCrudController;
use EasyCorp\Bundle\EasyAdminBundle\Field\AssociationField;
use EasyCorp\Bundle\EasyAdminBundle\Field\CurrencyField;
use EasyCorp\Bundle\EasyAdminBundle\Field\MoneyField;
use EasyCorp\Bundle\EasyAdminBundle\Field\NumberField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextEditorField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextField;

class RepasCrudController extends AbstractCrudController
{
    public static function getEntityFqcn(): string
    {
        return Repas::class;
    }


    public function configureFields(string $pageName): iterable
    {
        return [
            TextField::new('designation', "Title"),
            TextEditorField::new('description'),
            NumberField::new('prix', "Price"),
            NumberField::new('tva', "VAT Price"),
            TextField::new('img', 'Photo'),
            NumberField::new('quantite', "Quantity"),
            AssociationField::new('id_cat', "Category"),
        ];
    }

}
