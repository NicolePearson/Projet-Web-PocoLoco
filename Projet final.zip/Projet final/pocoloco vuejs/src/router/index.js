import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Categorie from "@/components/Categorie";
import UnRepas from "@/components/UnRepas";

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/:id?',
    name: 'Categories',
    component: Categorie
  },
  {
    path: '/repas/:id?',
    name: 'UnRepas',
    component: UnRepas
  },
  {
    path:'*',
    redirect : '/'
  }
]

const router = new VueRouter({
  routes
})

export default router
