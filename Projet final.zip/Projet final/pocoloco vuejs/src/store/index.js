import Vue from 'vue'
import Vuex from 'vuex'
import Axios from '../api/axios';

Axios()

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    plats:[],
    categories:[]
  },
  mutations: {
    setData(state,data){
      state.plats = data
    },
    setDataCategories(state,data){
      state.categories = data
    }
  },
  actions: {
    getDataApi(context){
      Axios().get('plats')
          .then(response => response.data)
          .then(donneesPlats => context.commit("setData", donneesPlats))
    },
    getCategories(context){
      Axios().get("http://localhost:8000/api/categories?page=1")
          .then(response => response.data)
          .then(donneesCategories => context.commit("setDataCategories", donneesCategories))
    }
  },
  modules: {
  }
})
