<template>
  <div id="app">
    <div id="site-header">
      <header id="header" class="header-block-top">
        <div class="container">
          <div class="row">
            <div class="main-menu">
              <!-- navbar -->
              <nav class="navbar navbar-default" id="mainNav">
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                          data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <div class="logo">
                    <router-link :to="{name: 'Home'}">
                      <img src="@/assets/images/logo.png" alt="">
                    </router-link>
                  </div>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                  <ul class="nav navbar-nav navbar-right">
                    <li><router-link :to="{name: 'Home'}">Menus</router-link></li>
                    <li><router-link :to="{name: 'Categories', params:{id:1}}">Starters</router-link></li>
                    <li><router-link :to="{name: 'Categories', params:{id:2}}">Main Courses</router-link></li>
                    <li><router-link :to="{name: 'Categories', params:{id:3}}">Desserts</router-link></li>
                    <li><router-link :to="{name: 'Categories', params:{id:4}}">Drinks</router-link></li>
                  </ul>
                </div>
                <!-- end nav-collapse -->
              </nav>
              <!-- end navbar -->
            </div>
          </div>
          <!-- end row -->
        </div>
        <!-- end container-fluid -->
      </header>
      <!-- end header -->
    </div>

  <main class="App__main">
    <transition name="fade" mode="out-in">
      <router-view :key="$route.fullPath"/>
    </transition>
  </main>
  </div>
</template>

<script>

export default {
  name: 'App',
  data() {
    return {
      transitionName: 'fade'
    }
  },
  created() {
    this.$router.beforeEach((to, from, next) => {
    let transitionName = to.meta.transitionName || from.meta.transitionName

    if (transitionName === 'slide') {
      const toDepth = to.path.split('/').length
      const fromDepth = from.path.split('/').length
      transitionName = toDepth < fromDepth ? 'slide-right' : 'slide-left'
    }

    this.transitionName = transitionName || 'fade'

    next()
    });
  }
}
</script>

<style>

#header {
  position: fixed;
}

/*SLIDE EFFECT*/
.fade-enter, .fade-leave-to{
  opacity: 0;
  transform: translate(2em);
}

.fade-enter-active, .fade-leave-active{
  transition: all .3s ease;
}
</style>
