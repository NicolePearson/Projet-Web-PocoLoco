<template>
  <div>
    <Plats/>
  </div>
</template>

<script>
// @ is an alias to /src
import Plats from '@/components/Plats.vue'

export default {
  name: 'Home',
  components: {
    Plats
  }
}
</script>
