<template>
  <div v-if="repas">
    <main>
      <section class="team-main pad-top-100 pad-bottom-100 parallax">
        <div class="product">
          <header>
            <h2 class="product">{{ repas.designation }}</h2>
          </header>
          <article class="flex">
            <img class="border" :src="require('../assets/'+repas.img)" alt="">
            <article class="flex2">
              <p>{{ repas.description }}</p>
              <p>{{ repas.tva }} $</p>
            </article>
          </article>
        </div>
        <div class="index">
          <div class="comment-form">
            <textarea type="text" v-model="comment" placeholder="Write a comment here..."></textarea>
            <label>
              <input  type="text" v-model="author" placeholder="Author name">
            </label>
            <button @click="addComment" class="bouton">Add Comment</button>
            <!-- <p>{{ comment }}</p> -->
          </div>
          <section v-if="comments">
            <div v-for="(comment,index) in comments" :key="index" class="comments-box">
              <p class="author">
                {{comment.auteur}} : {{ formatDate(comment.date) }}
              </p>
              <p class="author">{{comment.text}}</p>
              <button @click="removeComment(comment.id)" class="bouton">Remove</button>
            </div>
          </section>
        </div>
      </section>
    </main>
  </div>
</template>

<script>
import Axios from "@/api/axios";

export default {
  name: "UnRepas",
  data(){
    return {
      repas: null,
      comments : [],
      comment: null,
      author: null
    }
  },
  mounted() {
    Axios().get("http://localhost:8000/api"+this.$route.path)
        .then( (response) => {
          this.repas = response.data
          this.updateComment()
        })
        .catch( (err) => {
          console.error(err)
        })
  },
  methods:{
    addComment(){
      if(this.author && this.comment){
        Axios().post("http://localhost:8000/api/commentaires", {
              auteur : this.author,
              text : this.comment,
              repas : this.repas
            })
            .then( () => {
              this.updateComment()
            }).catch( (err) => {
              console.error(err)
            })
      } else {
        alert("Fields empty")
      }
    },
    removeComment(id){
      Axios().delete("http://localhost:8000/api/commentaires/" + id)
          .then( () => {
            this.updateComment()
          })
          .catch( (err) => {
            console.error(err)
          })
    },
    updateComment() {
      Axios().get("http://localhost:8000/api/commentaires")
          .then( (response) => {
            this.comments = response.data
            this.comments.map( (comment) => {comment.date = new Date(comment.date)} )
            this.comments = this.comments.filter( (comment) => { return comment.repas.id === this.repas.id })
            this.comments.reverse()
          })
          .catch( (err) => {
            console.error(err)
          })
    },
    formatDate(date) {
      let day = date.getUTCFullYear() + '-' + date.getUTCMonth() + '-' + date.getUTCDate()
      let hour = date.getUTCHours() + ":" + date.getUTCMinutes()
      return day + " at " + hour
    }
  }
}
</script>

<style scoped>

.comment-form{
  display: block;
  width: 80%;
  margin: auto;
}

textarea{
  width: 100%;
  border: 2px solid #ccc;
  border-radius: 7px;
  height: 70px;
  font-family: Verdana, Helvetica, sans-serif;
  padding: 5px;
}

input{
  border: 2px solid #ccc;
  border-radius: 5px;
  padding: 5px;
}

.comments-box{
  width: 90%;
  margin: auto;
  padding: 20px 0;
  border-bottom: 1px solid #000;
}

.author{
  margin: 10px 0;
  font-weight: bold;
  color: white;
}


</style>