<template>
  <div>
    <main>
      <div id="our_team" class="team-main pad-top-100 pad-bottom-100 parallax">
        <div class="container">
          <div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.1s">
            <h2 class="block-title text-center">All dishes</h2>
            <p class="title-caption text-center">There are many variations of passages of Lorem Ipsum available, but
              the majority have suffered alteration in some form, by injected humour, or randomised words which
              don't look even slightly believable. </p>
            <h2 class="block-title text-center" >Searching for something in particular...</h2>
            <div class="containerSearch index">
              <input v-model="search" placeholder='Search...' class='searchbar' type="text">
              <i class="fa fa-search"></i>
            </div>
            <p class="title-caption text-center index">{{this.compter}} results found</p>
          </div>
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="team-box">
                <div class="row">
                  <div class="col-md-6 col-sm-6 space" v-for="(repas, index) in recherche" :key="index">
                    <div class="sf-team">
                      <div class="thumb">
                        <router-link :to="{name: 'UnRepas', params:{id:repas.id}}">
                          <img :src="require('../assets/'+repas.img)" alt="">
                        </router-link>
                      </div>
                      <div class="text-col">
                        <router-link :to="{name: 'UnRepas', params:{id:repas.id}}">
                          <h3>{{ repas.designation }}</h3>
                        </router-link>
                        <p>{{ repas.description }}</p>
                        <ul class="team-social">
                          <li>{{ repas.tva }} $</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- end row -->
              </div>
              <!-- end team-box -->
            </div>
            <!-- end col -->
          </div>
          <!-- end row -->
        </div>
        <!-- end container -->
      </div>
      <!-- end team-main -->
    </main>
  </div>
</template>

<script>

export default {
  name: 'Plats',
  data(){
    return {
      search:''
    }
  },
  created() {
    this.$store.dispatch("getDataApi")
    this.$store.dispatch("getCategories")
  },
  computed: {
    plats() {
      return this.$store.state.plats;
    },
    categories(){
      return this.$store.state.categories;
    },
    recherche(){
      return this.$store.state.plats.filter((plat)=>{
        return plat.designation.toLowerCase().includes(this.search.toLowerCase())
      })
    },
    compter(){
      return this.recherche.length;
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}

input{
  position: relative;
}
</style>
