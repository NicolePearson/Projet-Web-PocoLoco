-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 21, 2021 at 03:59 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pocoloco`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`) VALUES
(1, 'Starters'),
(2, 'Main Dishes'),
(3, 'Desserts'),
(4, 'Drinks');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` int(11) NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` int(11) NOT NULL,
  `profile_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_C7440455E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `email`, `roles`, `password`, `name`, `surname`, `address`, `postal_code`, `city`, `phone_number`, `profile_img`) VALUES
(1, 'admin@email.com', '{\"roles\": \"ROLE_ADMIN\"}', '$argon2id$v=19$m=65536,t=4,p=1$eDlxb0NLZjd6QmZsRmdkcA$mFH9AlEhfF3KVMxwzOZqp9zOw8AFl5aUTs15qp+63kE', 'Nicole', 'Pearson', '82 Place Charles de Gaulle', 59650, 'Villeneuve-d\'ascq', 365905980, NULL),
(2, 'user@email.com', '{\"roles\": \"ROLE_USER\"}', '$argon2id$v=19$m=65536,t=4,p=1$d2xmUXREb0xKL1o3dGZiag$Ly8d5mm4B3aSRZ4O1RNL2DAequ9hmwNV7HjBYW1Roww', 'Hannah', 'Pierce', '59 avenue Ferdinand de Lesseps', 38000, 'Grenoble', 499801717, 'images/profile/avatar-605b3a590ac6e.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `prix_total` decimal(9,2) NOT NULL,
  `id_client_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6EEAA67D99DED506` (`id_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `commande`
--

INSERT INTO `commande` (`id`, `date`, `prix_total`, `id_client_id`) VALUES
(11, '2021-03-24 14:13:38', '38.00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auteur` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `repas_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_67F068BC1D236AAA` (`repas_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `commentaire`
--

INSERT INTO `commentaire` (`id`, `auteur`, `text`, `date`, `repas_id`) VALUES
(16, 'name', 'super comment', '2021-05-16 15:06:23', 2),
(17, 'Katy', 'Delicious ! ', '2021-05-21 15:08:34', 4);

-- --------------------------------------------------------

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
CREATE TABLE IF NOT EXISTS `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20210218111213', '2021-02-18 11:12:54', 212),
('DoctrineMigrations\\Version20210218112216', '2021-02-18 11:22:36', 252),
('DoctrineMigrations\\Version20210218112848', '2021-02-18 11:29:01', 1133),
('DoctrineMigrations\\Version20210218114248', '2021-02-18 11:43:07', 839),
('DoctrineMigrations\\Version20210218114814', '2021-02-18 11:48:29', 880),
('DoctrineMigrations\\Version20210305184931', '2021-03-05 18:50:12', 785),
('DoctrineMigrations\\Version20210305185736', '2021-03-05 18:57:55', 819),
('DoctrineMigrations\\Version20210316102258', '2021-03-16 10:23:26', 1889),
('DoctrineMigrations\\Version20210319144025', '2021-03-19 14:40:50', 826),
('DoctrineMigrations\\Version20210319145215', '2021-03-19 14:52:27', 1144),
('DoctrineMigrations\\Version20210319150019', '2021-03-19 15:00:24', 599),
('DoctrineMigrations\\Version20210319150855', '2021-03-19 15:09:14', 809),
('DoctrineMigrations\\Version20210319151706', '2021-03-19 15:17:23', 785),
('DoctrineMigrations\\Version20210319171508', '2021-03-19 17:15:30', 253),
('DoctrineMigrations\\Version20210319172341', '2021-03-19 17:23:54', 1474),
('DoctrineMigrations\\Version20210516093016', '2021-05-16 09:31:00', 709),
('DoctrineMigrations\\Version20210516122900', '2021-05-16 12:29:13', 2043);

-- --------------------------------------------------------

--
-- Table structure for table `ligne_commande`
--

DROP TABLE IF EXISTS `ligne_commande`;
CREATE TABLE IF NOT EXISTS `ligne_commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qte_repas` int(11) NOT NULL,
  `id_commande_id` int(11) NOT NULL,
  `id_repas_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3170B74B9AF8E3A3` (`id_commande_id`),
  KEY `IDX_3170B74B4DF8863F` (`id_repas_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ligne_commande`
--

INSERT INTO `ligne_commande` (`id`, `qte_repas`, `id_commande_id`, `id_repas_id`) VALUES
(13, 2, 11, 12),
(14, 1, 11, 16),
(15, 1, 11, 14),
(16, 1, 11, 13);

-- --------------------------------------------------------

--
-- Table structure for table `repas`
--

DROP TABLE IF EXISTS `repas`;
CREATE TABLE IF NOT EXISTS `repas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix` decimal(6,2) NOT NULL,
  `tva` decimal(5,1) NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantite` int(11) NOT NULL,
  `id_cat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_A8D351B3C09A1CAE` (`id_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `repas`
--

INSERT INTO `repas` (`id`, `designation`, `prix`, `tva`, `description`, `img`, `quantite`, `id_cat_id`) VALUES
(1, 'Southern Fried Chicken', '4.00', '6.0', 'Southern fried chicken with Mexican spice, comes with a sauce of your choice.', 'images/fried_chicken.jpg', 9, 1),
(2, 'Homemade Chocolat Brownie', '4.00', '6.0', 'Homemade chocolate brownie cake with chocolate sauce and whipped cream.', 'images/brownie.jpg', 10, 3),
(3, 'Mince Beef Burritos', '9.00', '12.0', 'Mince beef and vegetable burritos, comes with a side dish of your choice.', 'images/burritos.jpg', 10, 2),
(4, 'Mince Beef Tacos', '8.00', '10.0', 'Mince beef tacos accompanied with a fresh salad.', 'images/taco.jpg', 9, 2),
(5, 'Onion Rings', '3.00', '4.5', 'Fried onion rings accompanied with a sauce of your choice.', 'images/onion_rings.jpg', 10, 1),
(6, 'Pina Colada Cocktail', '4.00', '6.0', 'Fresh Pina Colada cocktail toped with a pineapple slice.', 'images/pina_colada.jpg', 10, 4),
(7, 'Chilli Cheese Nachos', '5.00', '6.5', 'Spicy mince beef nachos with chillies and cheese to share between two.', 'images/nachos.jpg', 10, 1),
(8, 'Spritz Cocktail', '4.00', '5.5', 'Spritz cocktail topped with orange slice.', 'images/spritz.jpg', 10, 4),
(9, 'Cuba Libre', '4.00', '5.5', 'Cuba Libre cocktail with lemon slice', 'images/cubalibre.jpg', 10, 4),
(10, 'Red Fruit Panna Cotta', '4.00', '5.0', 'Panna cotta with strawberry, rasberry and blueberry coulis', 'images/pannacotta.jpg', 10, 3),
(11, 'Strawberry Cheese Cake', '5.00', '6.0', 'Strawberry cheese cake topped with a strawberry coulis', 'images/cheesecake.jpg', 10, 3),
(12, 'Apple Pie', '4.00', '5.5', 'Homemade apple and cinnamon pie, served warm', 'images/applepie.jpg', 8, 3),
(13, 'Margarita Cocktail', '5.00', '6.5', 'Margarita cocktail with crushed ice and citrus fruits', 'images/margarita.jpg', 9, 4),
(14, 'Grilled chicken salad', '6.00', '8.0', 'A variety of fresh salad with delicious Mexican fried chicken', 'images/salad.jpg', 9, 1),
(15, 'Spicy Chicken Fajitas', '10.00', '12.5', 'Spicy chicken fajitas accompanied with wraps and salsa', 'images/fajita.jpg', 10, 2),
(16, 'Spicy Beef Fajitas', '10.00', '12.5', 'Spicy beef fajitas accompanied with wraps and salsa', 'images/beef.jpg', 9, 2);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `FK_6EEAA67D99DED506` FOREIGN KEY (`id_client_id`) REFERENCES `client` (`id`);

--
-- Constraints for table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `FK_67F068BC1D236AAA` FOREIGN KEY (`repas_id`) REFERENCES `repas` (`id`);

--
-- Constraints for table `ligne_commande`
--
ALTER TABLE `ligne_commande`
  ADD CONSTRAINT `FK_3170B74B4DF8863F` FOREIGN KEY (`id_repas_id`) REFERENCES `repas` (`id`),
  ADD CONSTRAINT `FK_3170B74B9AF8E3A3` FOREIGN KEY (`id_commande_id`) REFERENCES `commande` (`id`);

--
-- Constraints for table `repas`
--
ALTER TABLE `repas`
  ADD CONSTRAINT `FK_A8D351B3C09A1CAE` FOREIGN KEY (`id_cat_id`) REFERENCES `categorie` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
